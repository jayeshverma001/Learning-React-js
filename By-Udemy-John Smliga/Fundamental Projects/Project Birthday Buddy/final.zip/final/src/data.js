export default [
  {
    id: 1,
    name: 'Bertie Yates',
    age: 29,
    image: 'https://www.course-api.com/images/people/person-1.jpeg',
  },
  {
    id: 2,
    name: 'Hester Hogan',
    age: 32,
    image: 'https://www.course-api.com/images/people/person-2.jpeg',
  },
  {
    id: 3,
    name: 'Larry Little',
    age: 36,
    image: 'https://www.course-api.com/images/people/person-3.jpeg',
  },
  {
    id: 4,
    name: 'Sean Walsh',
    age: 34,
    image: 'https://www.course-api.com/images/people/person-4.jpeg',
  },
  {
    id: 5,
    name: 'Lola Gardner',
    age: 29,
    image: 'https://www.course-api.com/images/people/person-5.jpeg',
  },
];
