import React from 'react'

const Loading = () => {
  return (
    <div className='loading'>
      Loading
    </div>
  )
}

export default Loading;
